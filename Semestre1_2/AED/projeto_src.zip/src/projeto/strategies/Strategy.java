package projeto.strategies;

import projeto.draw.State;

public interface Strategy {
	public void execute(State state);
}
