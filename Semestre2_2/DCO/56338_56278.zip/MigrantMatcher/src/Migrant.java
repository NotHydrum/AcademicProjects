/**
 * Represents a migrant.
 * @author Miguel Nunes - 56338
 * @author Henrique Catarino - 56278
 */
public interface Migrant {
	
	/**
	 * @return The contact of the migrant.
	 */
	public int getContact();
	
}
