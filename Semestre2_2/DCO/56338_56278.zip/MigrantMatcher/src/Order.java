/**
 * Possible orders MigrantMatcher can return a list of aids in.
 * @author Miguel Nunes - 56338
 * @author Henrique Catarino - 56278
 */
public enum Order {
	NONE, OLD_TO_NEW, NEW_TO_OLD, HOUSING_FIRST, ITEMS_FIRST
}