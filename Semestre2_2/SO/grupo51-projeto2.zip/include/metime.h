#ifndef METIME_H_GUARD
#define METIME_H_GUARD

//gets current time
void get_time(struct timespec *timer);

#endif