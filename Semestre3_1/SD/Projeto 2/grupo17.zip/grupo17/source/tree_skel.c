//Grupo: 17
//Alunos:
//  Tiago Fernandes - 55246
//  Henrique Catarino - 56278
//  Miguel Nunes - 56338

#include <stdlib.h>

#include "tree_skel.h"
#include "tree-private.h"

struct tree_t *root;

int tree_skel_init() {
    root = tree_create();
    if (root == NULL) {
        return -1;
    }
    else {
        return 0;
    }
}

void tree_skel_destroy() {
    tree_destroy(root);
}

int invoke(MessageT *msg) {
    if (root != NULL) {
        if (msg->opcode == MESSAGE_T__OPCODE__OP_SIZE && msg->c_type == MESSAGE_T__C_TYPE__CT_NONE) {
            msg->opcode = MESSAGE_T__OPCODE__OP_SIZE + 1;
            msg->c_type = MESSAGE_T__C_TYPE__CT_RESULT;
            uint8_t size = tree_size(root);
            msg->n_data = 1;
            msg->data = malloc(sizeof(ProtobufCBinaryData));
            if (msg->data != NULL) {
                msg->data[0].len = 1;
                msg->data[0].data = &size;
                return 0;
            }
        }
        else if (msg->opcode == MESSAGE_T__OPCODE__OP_HEIGHT && msg->c_type == MESSAGE_T__C_TYPE__CT_NONE) {
            msg->opcode = MESSAGE_T__OPCODE__OP_HEIGHT + 1;
            msg->c_type = MESSAGE_T__C_TYPE__CT_RESULT;
            uint8_t height = tree_height(root);
            msg->n_data = 1;
            msg->data = malloc(sizeof(ProtobufCBinaryData));
            if (msg->data != NULL) {
                msg->data[0].len = 1;
                msg->data[0].data = &height;
                return 0;
            }
        }
        else if (msg->opcode == MESSAGE_T__OPCODE__OP_DEL && msg->c_type == MESSAGE_T__C_TYPE__CT_KEY &&
                msg->n_data == 1) {
            char *key = (char *)msg->data[0].data;
            if (root->node_1 != NULL || root->node_2 != NULL) {
                if (tree_del(root, key) == 0) {
                    msg->opcode = MESSAGE_T__OPCODE__OP_DEL + 1;
                    msg->c_type = MESSAGE_T__C_TYPE__CT_NONE;
                    msg->n_data = 0;
                    msg->data = NULL;
                    return 0;
                }
            }
            else {
                if (tree_del(root, key) == 0) {
                    msg->opcode = MESSAGE_T__OPCODE__OP_DEL + 1;
                    msg->c_type = MESSAGE_T__C_TYPE__CT_NONE;
                    msg->n_data = 0;
                    msg->data = NULL;
                    tree_skel_init();
                    return 0;
                }
            }
        }
        else if (msg->opcode == MESSAGE_T__OPCODE__OP_GET && msg->c_type == MESSAGE_T__C_TYPE__CT_KEY &&
                msg->n_data == 1) {
            char *key = (char *)msg->data[0].data;
            struct data_t *data = tree_get(root, key);
            if (data != NULL) {
                msg->opcode = MESSAGE_T__OPCODE__OP_GET + 1;
                msg->c_type = MESSAGE_T__C_TYPE__CT_VALUE;
                msg->n_data = 1;
                msg->data = malloc(sizeof(ProtobufCBinaryData));
                if (msg->data != NULL) {
                    msg->data[0].len = data->datasize;
                    msg->data[0].data = data->data;
                    free(data);
                    return 0;
                }
            }
        }
        else if (msg->opcode == MESSAGE_T__OPCODE__OP_PUT && msg->c_type == MESSAGE_T__C_TYPE__CT_ENTRY &&
                msg->n_data == 2) {
            struct data_t *value = malloc(sizeof(struct data_t));
            if (value != NULL) {
                value->datasize = msg->data[1].len;
                value->data = msg->data[1].data;
                if (tree_put(root, (char*)msg->data[0].data, value) == 0) {
                    msg->opcode = MESSAGE_T__OPCODE__OP_PUT + 1;
                    msg->c_type = MESSAGE_T__C_TYPE__CT_NONE;
                    msg->n_data = 0;
                    msg->data = NULL;
                    return 0;
                }
            }
        }
        else if (msg->opcode == MESSAGE_T__OPCODE__OP_GETKEYS && msg->c_type == MESSAGE_T__C_TYPE__CT_NONE) {
            char **keys = tree_get_keys(root);
            msg->n_data = 0;
            while (keys[msg->n_data] != NULL) {
                msg->n_data++;
            }
            msg->data = malloc(msg->n_data * sizeof(ProtobufCBinaryData));
            if (msg->data != NULL) {
                msg->opcode = MESSAGE_T__OPCODE__OP_GETKEYS + 1;
                msg->c_type = MESSAGE_T__C_TYPE__CT_KEYS;
                for (int i = 0; i < msg->n_data; i++) {
                    msg->data[i].len = sizeof(keys[i]);
                    msg->data[i].data = (uint8_t*)keys[i];
                }
                return 0;
            }
        }
        else if (msg->opcode == MESSAGE_T__OPCODE__OP_GETVALUES && msg->c_type == MESSAGE_T__C_TYPE__CT_NONE) {
            void **values = tree_get_values(root);
            msg->n_data = 0;
            while (values[msg->n_data] != NULL) {
                msg->n_data++;
            }
            msg->data = malloc(msg->n_data * sizeof(ProtobufCBinaryData));
            if (msg->data != NULL) {
                msg->opcode = MESSAGE_T__OPCODE__OP_GETVALUES + 1;
                msg->c_type = MESSAGE_T__C_TYPE__CT_VALUES;
                for (int i = 0; i < msg->n_data; i++) {
                    msg->data[i].len = sizeof(values[i]);
                    msg->data[i].data = values[i];
                }
                free(values);
                return 0;
            }
        }
    }
    msg->opcode = MESSAGE_T__OPCODE__OP_ERROR;
    msg->c_type = MESSAGE_T__C_TYPE__CT_NONE;
    msg->n_data = 0;
    msg->data = NULL;
    return -1;
}