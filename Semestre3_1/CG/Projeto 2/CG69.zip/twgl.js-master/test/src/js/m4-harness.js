/* global module */
/* global require */
require('should');
const loader = require("esm")(module);
loader('./m4-test.js');

